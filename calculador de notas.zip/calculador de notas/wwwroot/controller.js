 var app = angular.module("myApp", []);
    app.controller("myCtrl", function ($scope) {

        $scope.media = function () {

            $scope.valor1 = $scope.U1 / 100 * 30;
            $scope.valor2 = $scope.ED / 100 * 20;
            $scope.valor3 = $scope.U2 / 100 * 50;

            $scope.media = $scope.valor1 + $scope.valor2 + $scope.valor3;

            if ($scope.media >= 5.8) {

                $scope.style = { "color": "green" };
                $scope.status = "Aprovado!";
            }
            else {
                $scope.style = { "color": "red" };
                $scope.status = "Reprovado!";
            }
        }

    });

    app.controller("myCtrl2", function ($scope) {

            $scope.qtde = function () {
            $scope.valor1 = $scope.U1 / 100 * 30;
            $scope.valor2 = $scope.ED / 100 * 20;
            $scope.media = $scope.valor1 + $scope.valor2;
            var valorQuestao = 0.625 * 50;
            var minU2 = 2;
            var minQuestao = 4;
            var qtdeQuestao = 16;
            var nota = 0;

          if ($scope.media <= 1 )
            {
                nota = 5;
            }
            else if($scope.media >= 1 && $scope.media <= 2)
                {
                nota = 4.5;
                }
            
                else if($scope.media >= 2 && $scope.media <= 3)
                    {
                    nota = 4;
                }
                else if ($scope.media >= 3 && $scope.media <= 4) {
                    nota = 3.5;
                }
                else if ($scope.media >= 4 && $scope.media < 5) {
                    nota = 2;
                }
                else if ($scope.media = 5) {
                    nota = 1;
                }
           
            $scope.qtde = nota / 0.3125;
        }
    });